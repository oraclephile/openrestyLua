Run the decryption software in the encrypted file directory.

Thanks~

Usage: decryptor.exe
